package com.example.tincard

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.example.tincard.ui.theme.TincardTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TincardTheme {
                var currentScreen by remember { mutableStateOf("onboarding") }
                var userName by remember { mutableStateOf("Santiago") }
                var userPassword by remember { mutableStateOf("1234") }
                var userId by remember { mutableStateOf("admin") }
                
                val context = LocalContext.current

                when (currentScreen) {
                    "onboarding" -> OnboardingScreen(
                        onLoginClick = { currentScreen = "login" },
                        onRegisterClick = { currentScreen = "register" }
                    )
                    "register" -> RegisterScreen(
                        onRegisterSuccess = { name, id, pass ->
                            userName = name
                            userId = id
                            userPassword = pass
                            currentScreen = "login"
                            Toast.makeText(context, "Cuenta creada para $name. ¡Ya puedes ingresar!", Toast.LENGTH_LONG).show()
                        },
                        onBack = { currentScreen = "onboarding" }
                    )
                    "login" -> LoginScreen(
                        userName = userName,
                        onLoginSuccess = { currentScreen = "home" },
                        onBack = { currentScreen = "onboarding" },
                        validUsername = userId,
                        validPassword = userPassword
                    )
                    "home" -> HomeScreen(
                        userName = userName,
                        onUpdateName = { userName = it },
                        onLogout = { currentScreen = "login" }
                    )
                }
            }
        }
    }
}
