package com.example.tincard.ui.theme

import androidx.compose.ui.graphics.Color

val TinBlue = Color(0xFF004481)
val TinLightBlue = Color(0xFF1464A5)
val TinCyan = Color(0xFF2DCCCD)
val TinWhite = Color(0xFFFFFFFF)
val TinGrey = Color(0xFFF4F4F4)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)