package com.example.tincard

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tincard.ui.theme.TinBlue
import com.example.tincard.ui.theme.TinCyan
import com.example.tincard.ui.theme.TinGrey
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    userName: String,
    onUpdateName: (String) -> Unit,
    onLogout: () -> Unit
) {
    var selectedItem by remember { mutableIntStateOf(0) }
    val items = listOf("Inicio", "Mis cuentas", "Para ti", "Menú")
    val icons = listOf(Icons.Default.Home, Icons.Default.List, Icons.Default.Star, Icons.Default.Menu)
    
    var showTransferDialog by remember { mutableStateOf(false) }
    var showBreveDialog by remember { mutableStateOf(false) }
    var showAtmDialog by remember { mutableStateOf(false) }
    var showInvestDialog by remember { mutableStateOf(false) }
    
    var balance by remember { mutableDoubleStateOf(12450.00) }
    var investmentBalance by remember { mutableDoubleStateOf(5000.00) }
    val transactions = remember { mutableStateListOf(*getDummyTransactions().toTypedArray()) }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = when(selectedItem) {
                            1 -> "Mis Tarjetas"
                            2 -> "Para ti"
                            3 -> "Menú y Ajustes"
                            else -> "Hola, $userName"
                        },
                        color = Color.White, 
                        fontSize = 18.sp
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = { selectedItem = 3 }) {
                        Icon(Icons.Default.Person, contentDescription = "Profile", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { 
                        Toast.makeText(context, "No tienes notificaciones pendientes", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TinBlue)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                items.forEachIndexed { index, item ->
                    NavigationBarItem(
                        icon = { Icon(icons[index], contentDescription = item) },
                        label = { Text(item) },
                        selected = selectedItem == index,
                        onClick = { selectedItem = index },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TinBlue,
                            selectedTextColor = TinBlue,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray,
                            indicatorColor = TinCyan.copy(alpha = 0.2f)
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (selectedItem == 0 || selectedItem == 1) {
                var expanded by remember { mutableStateOf(false) }
                Box {
                    FloatingActionButton(
                        onClick = { expanded = true },
                        containerColor = TinCyan,
                        contentColor = TinBlue,
                        shape = RoundedCornerShape(50)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Operate")
                    }
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Transferencia normal") },
                            onClick = {
                                expanded = false
                                showTransferDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Transferencia BRE-V") },
                            onClick = {
                                expanded = false
                                showBreveDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Retiro sin tarjeta") },
                            onClick = {
                                expanded = false
                                showAtmDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Invertir") },
                            onClick = {
                                expanded = false
                                showInvestDialog = true
                            }
                        )
                    }
                }
            }
        },
        floatingActionButtonPosition = FabPosition.Center,
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            when (selectedItem) {
                1 -> CardsListScreen(userName)
                2 -> ForYouScreen()
                3 -> MenuScreen(userName, onUpdateName, onLogout)
                else -> DashboardScreen(
                    balance = balance, 
                    investmentBalance = investmentBalance,
                    transactions = transactions, 
                    userName = userName,
                    onActionClick = { action ->
                        when(action) {
                            "Transferir" -> showTransferDialog = true
                            "Retiro sin tarjeta" -> showAtmDialog = true
                            "Invertir" -> showInvestDialog = true
                            "Oportunidades" -> selectedItem = 2
                        }
                    }
                )
            }
        }

        if (showTransferDialog) {
            TransferDialog(
                title = "Nueva Transferencia",
                label = "Número de cuenta o CLABE",
                onDismiss = { showTransferDialog = false },
                onConfirm = { amount, desc ->
                    if (amount <= balance) {
                        balance -= amount
                        transactions.add(Transaction(desc, -amount, "Hoy"))
                        showTransferDialog = false
                    } else {
                        Toast.makeText(context, "Saldo insuficiente", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        if (showBreveDialog) {
            TransferDialog(
                title = "Transferencia BRE-V",
                label = "Número de celular o Alias",
                onDismiss = { showBreveDialog = false },
                onConfirm = { amount, desc ->
                    if (amount <= balance) {
                        balance -= amount
                        transactions.add(Transaction("BRE-V: $desc", -amount, "Hoy"))
                        showBreveDialog = false
                    } else {
                        Toast.makeText(context, "Saldo insuficiente", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        if (showAtmDialog) {
            AtmWithdrawDialog(
                onDismiss = { showAtmDialog = false },
                onConfirm = { amount ->
                    if (amount <= balance) {
                        balance -= amount
                        transactions.add(Transaction("Retiro sin tarjeta", -amount, "Hoy"))
                        showAtmDialog = false
                        Toast.makeText(context, "Código de retiro generado: ${ (100000..999999).random() }", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Saldo insuficiente", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        if (showInvestDialog) {
            InvestDialog(
                onDismiss = { showInvestDialog = false },
                onConfirm = { amount, type ->
                    if (amount <= balance) {
                        balance -= amount
                        investmentBalance += amount
                        transactions.add(Transaction("Inversión: $type", -amount, "Hoy"))
                        showInvestDialog = false
                        Toast.makeText(context, "Inversión realizada con éxito en $type", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Saldo insuficiente", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }
}

@Composable
fun DashboardScreen(balance: Double, investmentBalance: Double, transactions: List<Transaction>, userName: String, onActionClick: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TinGrey)
    ) {
        item {
            Box(modifier = Modifier
                .fillMaxWidth()
                .background(TinBlue)
                .padding(16.dp)) {
                Column {
                    Text(text = "SALDO DISPONIBLE", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
                    Text(text = "$${String.format(Locale.US, "%,.2f", balance)}", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "INVERSIONES", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
                    Text(text = "$${String.format(Locale.US, "%,.2f", investmentBalance)}", fontSize = 20.sp, fontWeight = FontWeight.Medium, color = TinCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Cuenta de $userName *1234", fontSize = 14.sp, color = Color.White)
                }
            }
        }

        item {
            QuickActionsRow(onActionClick)
        }

        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "ÚLTIMOS MOVIMIENTOS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            }
        }

        items(transactions.reversed()) { transaction ->
            TransactionItem(transaction)
        }
    }
}

@Composable
fun QuickActionsRow(onActionClick: (String) -> Unit) {
    val actions = listOf(
        Triple("Transferir", Icons.AutoMirrored.Filled.Send, "send"),
        Triple("Oportunidades", Icons.Default.Star, "info"),
        Triple("Retiro sin tarjeta", Icons.Default.AddCircle, "atm"),
        Triple("Invertir", Icons.Default.TrendingUp, "invest")
    )

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(actions) { action ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(80.dp)
                    .clickable { onActionClick(action.first) }
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    modifier = Modifier.size(56.dp),
                    shadowElevation = 2.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(action.second, contentDescription = action.first, tint = TinBlue)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = action.first, fontSize = 10.sp, textAlign = TextAlign.Center, lineHeight = 12.sp)
            }
        }
    }
}

@Composable
fun AtmWithdrawDialog(onDismiss: () -> Unit, onConfirm: (Double) -> Unit) {
    var amount by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Retiro sin tarjeta", color = TinBlue, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Ingresa el monto a retirar en cajero TinCard:")
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { if (it.all { char -> char.isDigit() }) amount = it },
                    label = { Text("Monto") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(amount.toDoubleOrNull() ?: 0.0) }, colors = ButtonDefaults.buttonColors(containerColor = TinCyan) ) {
                Text("Generar clave", color = TinBlue)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun InvestDialog(onDismiss: () -> Unit, onConfirm: (Double, String) -> Unit) {
    var amount by remember { mutableStateOf("") }
    val investmentTypes = listOf("Fondo Estrategia", "Acciones Tech", "Cripto-Basket", "Deuda Gobierno")
    var selectedType by remember { mutableStateOf(investmentTypes[0]) }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva Inversión", color = TinBlue, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Elige tu fondo de inversión:")
                Spacer(modifier = Modifier.height(8.dp))
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedType)
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        investmentTypes.forEach { type ->
                            DropdownMenuItem(text = { Text(type) }, onClick = {
                                selectedType = type
                                expanded = false
                            })
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { if (it.all { char -> char.isDigit() || char == '.' }) amount = it },
                    label = { Text("Monto a invertir") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(amount.toDoubleOrNull() ?: 0.0, selectedType) }, colors = ButtonDefaults.buttonColors(containerColor = TinCyan)) {
                Text("Invertir ahora", color = TinBlue)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun ForYouScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TinGrey)
            .padding(16.dp)
    ) {
        item {
            Text(text = "Para ti", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TinBlue)
            Spacer(modifier = Modifier.height(16.dp))
        }
        
        items(getDummyPromotions()) { promo ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = promo.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TinBlue)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = promo.description, fontSize = 14.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Saber más", color = TinCyan, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { })
                }
            }
        }
    }
}

data class Promotion(val title: String, val description: String)
fun getDummyPromotions() = listOf(
    Promotion("Seguro de Auto", "Protege tu vehículo con coberturas a tu medida y meses sin intereses."),
    Promotion("Apartados TinCard", "Organiza tu dinero creando apartados para tus ahorros o metas."),
    Promotion("Crédito Nómina", "Recibe un préstamo inmediato con la tasa más baja por ser cliente TinCard.")
)

@Composable
fun MenuScreen(
    userName: String,
    onUpdateName: (String) -> Unit,
    onLogout: () -> Unit
) {
    var newName by remember { mutableStateOf(userName) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TinGrey)
            .padding(24.dp)
    ) {
        Text(text = "Configuración de Cuenta", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TinBlue)
        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = newName,
            onValueChange = { newName = it },
            label = { Text("Nombre del Titular") },
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = { 
                onUpdateName(newName)
                Toast.makeText(context, "Nombre actualizado correctamente", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = TinBlue)
        ) {
            Text("Guardar Cambios", color = Color.White)
        }

        Spacer(modifier = Modifier.height(32.dp))
        
        Text(text = "Seguridad", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        ListItem(
            headlineContent = { Text("Cambiar contraseña") },
            leadingContent = { Icon(Icons.Default.Lock, contentDescription = null) },
            modifier = Modifier.clickable { }
        )
        ListItem(
            headlineContent = { Text("Límites de operación") },
            leadingContent = { Icon(Icons.Default.Info, contentDescription = null) },
            modifier = Modifier.clickable { }
        )

        Spacer(modifier = Modifier.weight(1f))

        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)
        ) {
            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Cerrar Sesión")
        }
    }
}

@Composable
fun CardsListScreen(userName: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TinGrey)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CardItem(lastDigits = "1234", name = userName.uppercase(), expiry = "12/27", type = "VISA")
        Spacer(modifier = Modifier.height(16.dp))
        CardItem(lastDigits = "5678", name = userName.uppercase(), expiry = "09/26", type = "MC")
        
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = TinCyan)
        ) {
            Text("Activar nueva tarjeta", color = TinBlue)
        }
    }
}

@Composable
fun CardItem(lastDigits: String, name: String, expiry: String, type: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = TinBlue)
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(40.dp, 25.dp).background(TinCyan, RoundedCornerShape(4.dp)))
                Text(text = type, color = Color.White, fontWeight = FontWeight.Bold)
            }
            
            Column(modifier = Modifier.align(Alignment.CenterStart)) {
                Text(text = "**** **** **** $lastDigits", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text(text = name, color = Color.LightGray, fontSize = 14.sp)
            }
            
            Text(
                text = expiry,
                color = TinCyan,
                modifier = Modifier.align(Alignment.BottomEnd),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun TransferDialog(
    title: String,
    label: String,
    onDismiss: () -> Unit,
    onConfirm: (Double, String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = TinBlue, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it },
                    label = { Text(label) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { if (it.all { char -> char.isDigit() || char == '.' }) amount = it },
                    label = { Text("Monto") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull()
                    if (amt != null && amt > 0 && destination.isNotBlank()) {
                        onConfirm(amt, destination)
                    } else {
                        Toast.makeText(context, "Datos inválidos", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TinCyan)
            ) {
                Text("Transferir", color = TinBlue)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
fun TransactionItem(transaction: Transaction) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        color = Color.White
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = transaction.description, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text(text = transaction.date, fontSize = 12.sp, color = Color.Gray)
            }
            Text(
                text = (if (transaction.amount > 0) "+" else "") + String.format(Locale.US, "%,.2f", transaction.amount),
                color = if (transaction.amount > 0) Color(0xFF2E7D32) else Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}

data class Transaction(val description: String, val amount: Double, val date: String)

fun getDummyTransactions() = listOf(
    Transaction("Supermercado Mercadona", -45.50, "Hoy"),
    Transaction("Transferencia de Bizum", 20.00, "Hoy"),
    Transaction("Recibo Vodafone", -32.00, "Ayer"),
    Transaction("Gasolinera Repsol", -50.00, "21 Oct"),
    Transaction("Nómina Empresa S.L.", 2100.00, "15 Oct")
)
