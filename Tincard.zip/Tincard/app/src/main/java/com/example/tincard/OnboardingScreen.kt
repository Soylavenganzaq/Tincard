package com.example.tincard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tincard.ui.theme.TinBlue
import com.example.tincard.ui.theme.TinCyan
import com.example.tincard.ui.theme.TinGrey

@Composable
fun OnboardingScreen(
    onLoginClick: () -> Unit,
    onRegisterClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TinGrey),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .background(TinBlue),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Bienvenido a TinCard",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        // Card Illustration
        Card(
            modifier = Modifier
                .size(280.dp, 180.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = TinBlue)
        ) {
            Box(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = null,
                    tint = TinCyan,
                    modifier = Modifier.size(40.dp)
                )
                Icon(
                    Icons.Default.Info,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.TopEnd).size(30.dp)
                )
                Text(
                    text = "**** 4821",
                    color = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))

        Text(
            text = "Tu banco digital,\nsiempre contigo",
            color = TinBlue,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "La libertad de mover tu dinero",
            color = TinCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Gestiona tus cuentas, tarjetas e inversiones\ndesde la palma de tu mano.",
            color = Color.Gray,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 40.dp)
        )

        Spacer(modifier = Modifier.weight(1f))

        // Actions
        Button(
            onClick = onLoginClick,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TinBlue),
            shape = RoundedCornerShape(25.dp)
        ) {
            Text("Ya soy cliente (Entrar)", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onRegisterClick,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(50.dp),
            border = ButtonDefaults.outlinedButtonBorder.copy(width = 2.dp),
            shape = RoundedCornerShape(25.dp)
        ) {
            Text("Abrir mi cuenta TinCard", color = TinBlue, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(48.dp))
    }
}
